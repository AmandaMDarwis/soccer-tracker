﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Soccer_Team_Players_Tracker.Form1;

namespace Soccer_Team_Players_Tracker
{
    public partial class Form1 : Form
    {
        private List<Team> teams = new List<Team>();

        public class Team
        {
            public string teamName;
            public string teamCountry;
            public string teamCity;
            public List<Player> players = new List<Player>();

            public Team(string teamName, string teamCountry, string teamCity)
            {
                this.teamName = teamName;
                this.teamCountry = teamCountry;
                this.teamCity = teamCity;
            }
        }

        public class Player
        {
            public string playerName;
            public string playerNum;
            public string playerPos;

            public Player(string playerName, string playerNum, string playerPos)
            {
                this.playerName = playerName;
                this.playerNum = playerNum;
                this.playerPos = playerPos;
            }
        }

        public Form1()
        {
            InitializeComponent();
            // add team dan player awal
            Team team1 = new Team("Persija", "Indonesia", "Jakarta");
            cbCountry.Items.Add("Indonesia");
            team1.players.Add(new Player("Rio Fahmi", "02", "DF")); //1
            //teams.Add(team1);
            team1.players.Add(new Player("Dandi Maulana", "05", "DF")); //2
            //teams.Add(team1);
            team1.players.Add(new Player("Tony Sucipto", "06", "DF")); //3
            //teams.Add(team1);
            team1.players.Add(new Player("Syahrian Abimanyu", "08", "MF")); //4
            //teams.Add(team1);
            team1.players.Add(new Player("Adre Arido", "13", "GK")); //5
            //teams.Add(team1);
            team1.players.Add(new Player("Hanif Sjahbandi", "19", "MF"));//6
            //teams.Add(team1);
            team1.players.Add(new Player("Alfriyanto Nico", "21", "MF")); //7
            //teams.Add(team1);
            team1.players.Add(new Player("Hansamu Yama", "23", "DF")); //8
            //teams.Add(team1);
            team1.players.Add(new Player("Resky Fandi", "24", "MF")); //9
            //teams.Add(team1);
            team1.players.Add(new Player("Riko Simanjuntak", "25", "MF")); //10
            //teams.Add(team1);
            team1.players.Add(new Player("Andritany Ardhiyasa", "26", "GK")); //11
            teams.Add(team1);

            Team team2 = new Team("Persebaya", "Indonesia", "Surabaya");            
            team2.players.Add(new Player("Emando Ari", "21", "GK")); //1            
            team2.players.Add(new Player("Andhika Ramadhani", "52", "GK")); //2           
            team2.players.Add(new Player("Aditya Arya", "64", "GK")); //3            
            team2.players.Add(new Player("Lalu Rizki", "01", "GK")); //4            
            team2.players.Add(new Player("Miftakul Yunan", "15", "GK")); //5            
            team2.players.Add(new Player("Kadek Raditya", "23", "DF"));//6            
            team2.players.Add(new Player("Riswan Lauhim", "32", "DF")); //7            
            team2.players.Add(new Player("Reva Adi Utama", "03", "DF")); //8            
            team2.players.Add(new Player("Salman Alfarid", "24", "DF")); //9            
            team2.players.Add(new Player("Rifqi Arya", "73", "DF")); //10            
            team2.players.Add(new Player("Arief Catur", "02", "DF")); //11
            teams.Add(team2);

            Team team3 = new Team("Deinze", "Belgia", "Deinze");
            cbCountry.Items.Add("Belgia");
            team3.players.Add(new Player("Laurent Lemoine", "05", "DF")); //1                                                                    
            team3.players.Add(new Player("Steve De Ridder", "06", "MF")); //2                                                                        
            team3.players.Add(new Player("Alessio Staelens", "07", "MF")); //3                                                                       
            team3.players.Add(new Player("Guillaume De Schryver", "08", "MF")); //4                                                                           
            team3.players.Add(new Player("Dylan De Belder", "09", "FW")); //5                                                                     
            team3.players.Add(new Player("Christophe Janssens", "16", "DF"));//6                                                                        
            team3.players.Add(new Player("Jannes Vansteenkiste", "17", "DF")); //7                                                                          
            team3.players.Add(new Player("Jellert Van Landschoot", "28", "FW")); //8                                                                       
            team3.players.Add(new Player("Kenneth Schuermans", "23", "DF")); //9                                                                      
            team3.players.Add(new Player("Andreas Spegelaere", "25", "DF")); //10                                                                           
            team3.players.Add(new Player("Llian Mhand", "26", "MF")); //11
            teams.Add(team3);
        }

        private void btnAddTeam_Click(object sender, EventArgs e)
        {
            bool checkTeam = true;
            foreach(string team in cbTeam.Items)
            {
                if (team == tbTeamName.Text)
                {
                    MessageBox.Show("Team Name already exist");           
                    checkTeam = false;
                }                                
            }
            if (tbTeamName.Text.Length < 1 || tbTeamCountry.Text.Length < 1 || tbTeamCity.Text.Length < 1)
            {
                MessageBox.Show("You have to fill all the textbox");
                checkTeam = false;
            }
            else if(checkTeam == true)
            {
                string nameTeam = tbTeamName.Text;
                string countryTeam = tbTeamCountry.Text;
                string cityTeam = tbTeamCity.Text;
                Team newTeam = new Team(nameTeam, countryTeam, cityTeam);
                teams.Add(newTeam);
                cbCountry.Items.Add(countryTeam);
                if (cbCountry.SelectedIndex != -1 && cbCountry.Text.ToString() == countryTeam)
                {
                    cbTeam.Items.Add(nameTeam);
                }
                tbTeamName.Text = "";
                tbTeamCountry.Text = "";
                tbTeamCity.Text = "";
            }

        }

        private void btnAddPlayer_Click(object sender, EventArgs e)
        {
            bool checkPlayer = true;
            string chosenTeamName = cbTeam.Text;
            Team chosenTeam = null;

            if (!String.IsNullOrEmpty(chosenTeamName))
            {
                foreach(Team team in teams)
                {
                    if (team.teamName == chosenTeamName)
                    {
                        chosenTeam = team;
                    }
                }
            } else
            {                
                MessageBox.Show("You must choose a team");
                checkPlayer = false;
            }

            if (checkPlayer == true)
            {
                foreach (Player player in chosenTeam.players)
                {
                    if (player.playerName == tbPlyrName.Text)
                    {
                        MessageBox.Show("Player Name already exist");
                        checkPlayer = false;
                    }
                }
            }
            

            if (tbPlyrName.Text.Length < 1 || tbPlyrNum.Text.Length < 1 || cbPlyrPosition.SelectedItem == null)
            {
                MessageBox.Show("You have to fill all the textbox");
                checkPlayer = false;
            }
            else if (checkPlayer == true)
            {
                if (cbTeam.SelectedIndex == -1 || cbCountry.SelectedIndex == -1)
                {
                    MessageBox.Show("Must choose a team and a country");
                }
                else
                {
                    lbPlayers.Items.Clear();
                    string namePlayer = tbPlyrName.Text;
                    string numberPlayer = tbPlyrNum.Text;
                    string positionPlayer = Convert.ToString(cbPlyrPosition.SelectedItem);
                    Player newPlayer = new Player(namePlayer, numberPlayer, positionPlayer);
                    foreach (Team team in teams)
                    {
                        if (team.teamName == cbTeam.Text)
                        {
                            team.players.Add(newPlayer);
                            foreach (Player player in team.players)
                            {
                                lbPlayers.Items.Add($"({player.playerNum}), {player.playerName}, {player.playerPos}");
                            }
                            break;
                        }
                    }                                        

                    tbPlyrName.Text = "";
                    tbPlyrNum.Text = "";
                    cbPlyrPosition.SelectedItem = null;
                }
                
            }

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            foreach (Team team in teams)
            {
                if (team.teamName == cbTeam.Text)
                {
                    if (team.players.Count < 12)
                    {
                        MessageBox.Show("Can't Remove if players are less than 11");
                    }
                    else
                    {
                        team.players.RemoveAt(lbPlayers.SelectedIndex);
                        lbPlayers.Items.Remove(lbPlayers.SelectedItem);
                    }
                    break;
                }
            }

            
        }

        private void cbCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbTeam.Items.Clear();
            cbTeam.Text = null;
            lbPlayers.Items.Clear();

            string chosenCountryName = cbCountry.SelectedItem.ToString();
            List<Team> availableTeams = teamsContainCountry(chosenCountryName);

            foreach (Team avalailableTeam in availableTeams)
            {
                cbTeam.Items.Add(avalailableTeam.teamName);
            }
        }

        private List<Team> teamsContainCountry(string countryName)
        {
            List<Team> temp = new List<Team>();

            foreach (Team team in teams)
            {
                if (team.teamCountry == countryName)
                {
                    temp.Add(team);
                }
            }

            return temp;
        }

        private void cbTeam_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbPlayers.Items.Clear();

            string chosenTeamName = cbTeam.SelectedItem.ToString();

            if (chosenTeamName != null )
            {
                foreach (Team team in teams)
                {
                    if (team.teamName == chosenTeamName)
                    {
                        Team chosenTeam = team;
                        foreach (Player player in chosenTeam.players)
                        {
                            lbPlayers.Items.Add($"({player.playerNum}), {player.playerName}, {player.playerPos}");
                        }
                        break;
                    }
                }
            }
            
        }
    }
}
